Copy the following libraries to this folder:
Cognifide.PowerShell.dll
Sitecore.Kernel.dll